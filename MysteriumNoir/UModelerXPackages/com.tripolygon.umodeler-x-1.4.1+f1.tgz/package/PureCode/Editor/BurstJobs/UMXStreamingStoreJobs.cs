#if !UNITY_EDITOR_OSX
using Unity.Burst;
using Unity.Burst.Intrinsics;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Jobs;
using UnityEditor;

namespace Tripolygon.UModelerX.Editor
{
    /// <summary>
    /// 초대형 채우기/복사의 스트리밍(논템포럴) 저장 경로 — <see cref="IUMXStreamingStores"/> 구현.
    ///
    /// x86 전용 인트린식(SSE2 stream_si128)을 쓰므로 DLL(BurstKernels)이 아니라 이 소스 배포 어셈블리에 둡니다.
    /// DLL 은 윈도우에서 한 번 빌드되어 모든 OS 에 그대로 배포되므로 #if 로 가를 수 없지만,
    /// 이 파일은 소비자 에디터에서 컴파일되어 UNITY_EDITOR_OSX 가 그 자리에서 평가됩니다.
    /// 맥 에디터에서는 파일 전체가 빠져 x86 코드가 컴파일되지 않고, 브리지가 null 로 남아
    /// DLL 의 일반 채우기/복사 커널이 처리합니다.
    ///
    /// 유니티에는 에디터 CPU 아키텍처(x64/ARM64)를 가르는 스크립팅 디파인이 없어 OS 로 가릅니다
    /// (UNITY_EDITOR_64·PLATFORM_ARCH_64 는 64비트 여부뿐). 그래서 인텔 맥도 이 경로를 쓰지 않습니다.
    ///
    /// 커널 안의 IsSse2Supported 가드는 이와 별개로 유지합니다. 윈도우 ARM 에디터처럼 맥이 아니면서
    /// x86 도 아닌 환경에서 컴파일될 때 BC1200 없이 일반 저장으로 떨어지게 하는 안전장치입니다.
    /// 버스트의 CPU 기능 검사는 블록 단위라 인트린식과 같은 메서드 안에서 감싸야 합니다.
    /// </summary>
    internal sealed unsafe class UMXStreamingStoreScheduler : IUMXStreamingStores
    {
        public bool TryFill(byte* destination, byte* patternValue, int strideBytes, int count, int chunkSize, int chunkCount)
        {
            /// 16바이트 벡터에 정수 개로 들어가는 스트라이드만 다룹니다(12=Vector3 등은 일반 채우기).
            if (strideBytes != 4 && strideBytes != 8 && strideBytes != 16)
            {
                return false;
            }

            /// 패턴을 워드로 미리 풀어 잡 필드(ulong 2개)에 담습니다.
            var pattern = stackalloc ulong[2];
            pattern[0] = 0;
            pattern[1] = 0;
            UnsafeUtility.MemCpy(pattern, patternValue, strideBytes);

            var fillJob = new UMXParallelKernelJob<UMXStreamingFillKernel>
            {
                kernel = new UMXStreamingFillKernel
                {
                    destination = destination,
                    patternValue = patternValue,
                    pattern0 = pattern[0],
                    pattern1 = pattern[1],
                    strideBytes = strideBytes,
                    count = count,
                    chunkSize = chunkSize,
                },
            };

            if (chunkCount < 2)
            {
                fillJob.Run(chunkCount);
            }
            else
            {
                /// 병렬 인덱스가 청크라 배치 인자는 1(워커가 청크 하나씩)이어야 합니다.
                fillJob.Schedule(chunkCount, 1).Complete();
            }
            return true;
        }

        public bool TryCopy(byte* source, byte* destination, long totalBytes, long chunkBytes, int chunkCount)
        {
            var copyJob = new UMXParallelKernelJob<UMXStreamingCopyKernel>
            {
                kernel = new UMXStreamingCopyKernel
                {
                    source = source,
                    destination = destination,
                    totalBytes = totalBytes,
                    chunkBytes = chunkBytes,
                },
            };

            if (chunkCount < 2)
            {
                copyJob.Run(chunkCount);
            }
            else
            {
                /// 병렬 인덱스가 청크라 배치 인자는 1(워커가 청크 하나씩)이어야 합니다.
                copyJob.Schedule(chunkCount, 1).Complete();
            }
            return true;
        }

        public void Warmup()
        {
            /// Run 은 메인 스레드에서 동기로 끝나므로 스택 버퍼여도 안전합니다.
            var source = stackalloc ulong[8];
            var destination = stackalloc ulong[8];
            for (int i = 0; i < 8; i++)
            {
                source[i] = 0;
            }
            uint warmupPattern = 0;

            new UMXParallelKernelJob<UMXStreamingFillKernel>
            {
                kernel = new UMXStreamingFillKernel
                {
                    destination = (byte*)destination,
                    patternValue = (byte*)&warmupPattern,
                    strideBytes = 4,
                    count = 16,
                    chunkSize = 16,
                },
            }.Run(1);

            new UMXParallelKernelJob<UMXStreamingCopyKernel>
            {
                kernel = new UMXStreamingCopyKernel
                {
                    source = (byte*)source,
                    destination = (byte*)destination,
                    totalBytes = 64,
                    chunkBytes = 64,
                },
            }.Run(1);
        }
    }

    /// <summary>
    /// 스트리밍 저장 패턴 채우기 커널(스트라이드 4/8/16 전용).
    /// 16바이트 정렬 지점까지 앞부분과 벡터로 안 떨어지는 꼬리는 MemCpyReplicate 로 처리합니다.
    /// </summary>
    internal unsafe struct UMXStreamingFillKernel : IUMXParallelKernel
    {
        [NoAlias, NativeDisableUnsafePtrRestriction] public byte* destination;
        /// <summary>채울 값(요소 하나) 원본. 잡 완료까지 살아 있어야 합니다.</summary>
        [NoAlias, NativeDisableUnsafePtrRestriction] public byte* patternValue;
        /// <summary>패턴값의 앞 8바이트.</summary>
        public ulong pattern0;
        /// <summary>패턴값의 뒤 8바이트. 스트라이드가 8 이하면 쓰이지 않습니다.</summary>
        public ulong pattern1;
        public int strideBytes;
        /// <summary>채울 전체 요소 수.</summary>
        public int count;
        /// <summary>청크 하나가 맡는 요소 수. 청크끼리 구간이 겹치지 않아 병렬 쓰기가 안전합니다.</summary>
        public int chunkSize;

        public void Execute(int chunkIndex)
        {
            var start = chunkIndex * this.chunkSize;
            var end = start + this.chunkSize;
            if (end > this.count)
            {
                end = this.count;
            }
            var elementCount = end - start;
            if (elementCount <= 0)
            {
                return;
            }

            ExecuteStreaming(this.destination + (long)start * this.strideBytes, elementCount);
        }

        private void ExecuteStreaming(byte* dstBytes, int elementCount)
        {
            var stride = this.strideBytes;
            var elementsPerVector = 16 / stride;

            /// 16바이트 정렬까지의 앞부분. 남는 바이트가 요소 경계로 안 떨어지면
            /// (버퍼 시작 정렬이 어긋난 드문 경우) 이 청크는 통째로 일반 저장합니다.
            var misalignBytes = (int)((ulong)dstBytes & 15);
            if (misalignBytes != 0)
            {
                var headBytes = 16 - misalignBytes;
                if (headBytes % stride != 0)
                {
                    UnsafeUtility.MemCpyReplicate(dstBytes, this.patternValue, stride, elementCount);
                    return;
                }

                var headElements = headBytes / stride;
                if (headElements > elementCount)
                {
                    headElements = elementCount;
                }
                UnsafeUtility.MemCpyReplicate(dstBytes, this.patternValue, stride, headElements);
                dstBytes += headElements * stride;
                elementCount -= headElements;
            }

            /// v128 하나에 패턴을 요소 수만큼 복제해 캐시 우회로 저장합니다.
            var word0 = (uint)this.pattern0;
            var word1 = (uint)(this.pattern0 >> 32);
            var word2 = (uint)this.pattern1;
            var word3 = (uint)(this.pattern1 >> 32);
            var patternVector = stride == 4 ? new v128(word0, word0, word0, word0)
                : stride == 8 ? new v128(word0, word1, word0, word1)
                : new v128(word0, word1, word2, word3);

            /// 인트린식 블록은 이 메서드 안에서 직접 감싸야 x86 이 아닌 타깃에서 BC1200 이 나지 않습니다.
            /// (관리 폴백에서도 false 라 아래 꼬리 처리가 전부 채웁니다)
            if (X86.Sse2.IsSse2Supported)
            {
                var vectorCount = (long)elementCount / elementsPerVector;
                for (long vectorIndex = 0; vectorIndex < vectorCount; ++vectorIndex)
                {
                    X86.Sse2.stream_si128(dstBytes, patternVector);
                    dstBytes += 16;
                }
                elementCount -= (int)(vectorCount * elementsPerVector);
            }

            if (elementCount > 0)
            {
                UnsafeUtility.MemCpyReplicate(dstBytes, this.patternValue, stride, elementCount);
            }

            /// 스트리밍 저장은 쓰기 결합 버퍼에 머무를 수 있어, 이 청크가 끝났다는 신호가
            /// 다른 스레드에 보이기 전에 저장을 전부 밀어내도록 전체 펜스로 마감합니다.
            /// (이 버스트 버전엔 sfence 인트린식이 없어 MemoryBarrier 를 씁니다 — x86 에서
            ///  전체 펜스/락 연산은 쓰기 결합 버퍼도 밀어냅니다)
            System.Threading.Thread.MemoryBarrier();
        }
    }

    /// <summary>
    /// 스트리밍 저장 복사 커널. 대상을 16바이트 정렬로 맞춘 뒤 원본은 비정렬 로드, 대상은 스트리밍 저장으로 복사합니다.
    /// 정렬 앞머리와 16바이트 미만 꼬리는 일반 MemCpy 로 처리합니다. 원본과 대상은 겹치지 않아야 합니다.
    /// </summary>
    internal unsafe struct UMXStreamingCopyKernel : IUMXParallelKernel
    {
        [NoAlias, NativeDisableUnsafePtrRestriction] public byte* source;
        [NoAlias, NativeDisableUnsafePtrRestriction] public byte* destination;
        public long totalBytes;
        /// <summary>청크 하나가 맡는 바이트 수. 청크끼리 구간이 겹치지 않아 병렬 복사가 안전합니다.</summary>
        public long chunkBytes;

        public void Execute(int chunkIndex)
        {
            var offset = chunkIndex * this.chunkBytes;
            var size = this.chunkBytes;
            if (offset + size > this.totalBytes)
            {
                size = this.totalBytes - offset;
            }
            if (size <= 0)
            {
                return;
            }

            ExecuteStreaming(offset, size);
        }

        private void ExecuteStreaming(long offset, long size)
        {
            var src = this.source + offset;
            var dst = this.destination + offset;

            var misalignBytes = (int)((ulong)dst & 15);
            if (misalignBytes != 0)
            {
                long headBytes = 16 - misalignBytes;
                if (headBytes > size)
                {
                    headBytes = size;
                }
                UnsafeUtility.MemCpy(dst, src, headBytes);
                src += headBytes;
                dst += headBytes;
                size -= headBytes;
            }

            /// 인트린식 블록은 이 메서드 안에서 직접 감싸야 x86 이 아닌 타깃에서 BC1200 이 나지 않습니다.
            /// (관리 폴백에서도 false 라 아래 꼬리 처리가 전부 복사합니다)
            if (X86.Sse2.IsSse2Supported)
            {
                var vectorCount = size / 16;
                for (long vectorIndex = 0; vectorIndex < vectorCount; ++vectorIndex)
                {
                    /// 원본 읽기는 정렬 무관 로드(캐시 경유 — 프리페처가 순차 읽기를 잘 따라옵니다).
                    X86.Sse2.stream_si128(dst, X86.Sse2.loadu_si128(src));
                    src += 16;
                    dst += 16;
                }
                size -= vectorCount * 16;
            }

            if (size > 0)
            {
                UnsafeUtility.MemCpy(dst, src, size);
            }

            /// 스트리밍 저장은 쓰기 결합 버퍼에 머무를 수 있어, 이 청크가 끝났다는 신호가
            /// 다른 스레드에 보이기 전에 저장을 전부 밀어내도록 전체 펜스로 마감합니다.
            /// (이 버스트 버전엔 sfence 인트린식이 없어 MemoryBarrier 를 씁니다)
            System.Threading.Thread.MemoryBarrier();
        }
    }

    [InitializeOnLoad]
    internal static class UMXStreamingStoreInstaller
    {
        static UMXStreamingStoreInstaller()
        {
            UMXBurstJobBridge.StreamingStores = new UMXStreamingStoreScheduler();
        }

        /// <summary>
        /// 버스트가 닫힌 제네릭 잡을 찾도록 메타데이터에 남깁니다.
        /// UMXBurstJobSchedulerInstaller 의 핀 목록과 같은 이유입니다(메서드 본문 IL 은 탐색 대상이 아님).
        /// </summary>
#pragma warning disable 0169
        private static UMXParallelKernelJob<UMXStreamingFillKernel> pinUMXStreamingFillKernel;
        private static UMXParallelKernelJob<UMXStreamingCopyKernel> pinUMXStreamingCopyKernel;
#pragma warning restore 0169
    }
}
#endif
