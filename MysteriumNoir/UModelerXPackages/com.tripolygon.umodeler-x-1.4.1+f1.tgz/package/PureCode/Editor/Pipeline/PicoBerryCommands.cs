using System.Threading.Tasks;
using Tripolygon.UModelerX.Editor.MCP;
using Unity.Pipeline.Commands;

namespace Tripolygon.UModelerX.Editor.Pipeline
{
    // Unity Pipeline 어댑터. 프로토콜 변환만 담당하고 실제 실행은 Core 의 PicoBerry*Operation 으로 위임.
    //
    // 파라미터 선언 순서와 Required 는 이 패키지에서 와이어 API 다(클라이언트가 위치 인자로 바인딩한다).
    // 새 인자는 반드시 뒤에 붙이고, 기존 인자의 순서나 필수 여부는 바꾸지 않는다.
    static class PicoBerryCommands
    {
        [CliCommand(
            "umx_picoberry_generate",
            UMXPicoBerryToolText.GenerateDescription,
            Tags = new[] { "umodelerx/picoberry" })]
        public static object Generate(
            [CliArg("prompt", UMXPicoBerryToolText.PromptParam)] string prompt = null,
            [CliArg("image_path", UMXPicoBerryToolText.ImagePathParam)] string imagePath = null,
            [CliArg("model", UMXPicoBerryToolText.ModelParam)] string model = null,
            [CliArg("texture", UMXPicoBerryToolText.TextureParam)] bool texture = true,
            [CliArg("high_res_texture", UMXPicoBerryToolText.HighResTextureParam)] bool highResTexture = false,
            [CliArg("t_pose", UMXPicoBerryToolText.TPoseParam)] bool tPose = false,
            [CliArg("polygon_count", UMXPicoBerryToolText.PolygonCountParam)] int polygonCount = 0,
            [CliArg("name", UMXPicoBerryToolText.NameParam)] string name = null,
            [CliArg("position", UMXPicoBerryToolText.PositionParam)] string position = null,
            [CliArg("rotation", UMXPicoBerryToolText.RotationParam)] string rotation = null,
            [CliArg("scale", UMXPicoBerryToolText.ScaleParam)] string scale = null,
            [CliArg("parent", UMXPicoBerryToolText.ParentParam)] string parent = null)
        {
            var buildError = UMXPicoBerryRequestBuilder.BuildGenerate(
                prompt: prompt,
                imagePath: imagePath,
                model: model,
                texture: texture,
                highResTexture: highResTexture,
                tPose: tPose,
                polygonCount: polygonCount,
                name: name,
                position: position,
                rotation: rotation,
                scale: scale,
                parent: parent,
                out var request);

            if (buildError != null) return UMXPipelineResponse.Unwrap(buildError);

            return UMXPipelineResponse.Unwrap(PicoBerryGenerateOperation.Execute(request));
        }

        [CliCommand(
            "umx_picoberry_status",
            UMXPicoBerryToolText.StatusDescription,
            Tags = new[] { "umodelerx/picoberry" })]
        public static object Status(
            [CliArg("session_id", UMXPicoBerryToolText.SessionIdParam)] string sessionId = null)
        {
            var request = new PicoBerryStatusRequest { SessionId = sessionId };
            return UMXPipelineResponse.Unwrap(PicoBerryStatusOperation.Execute(request));
        }

        [CliCommand(
            "umx_picoberry_wait",
            UMXPicoBerryToolText.WaitDescription,
            Tags = new[] { "umodelerx/picoberry" })]
        public static Task<object> Wait(
            [CliArg("session_id", UMXPicoBerryToolText.SessionIdParam, Required = true)] string sessionId,
            [CliArg("timeout_seconds", UMXPicoBerryToolText.TimeoutSecondsParam)] int timeoutSeconds = PicoBerryWaitRequest.DefaultTimeoutSeconds)
        {
            var request = new PicoBerryWaitRequest
            {
                SessionId = sessionId,
                TimeoutSeconds = timeoutSeconds > 0
                    ? timeoutSeconds
                    : PicoBerryWaitRequest.DefaultTimeoutSeconds,
            };
            return UMXPipelineResponse.UnwrapAsync(PicoBerryWaitOperation.ExecuteAsync(request));
        }

        [CliCommand(
            "umx_picoberry_place",
            UMXPicoBerryToolText.PlaceDescription,
            Tags = new[] { "umodelerx/picoberry" })]
        public static Task<object> Place(
            [CliArg("session_id", UMXPicoBerryToolText.SessionIdParam)] string sessionId = null,
            [CliArg("asset_id", UMXPicoBerryToolText.AssetIdParam)] string assetId = null,
            [CliArg("name", UMXPicoBerryToolText.NameParam)] string name = null,
            [CliArg("position", UMXPicoBerryToolText.PositionParam)] string position = null,
            [CliArg("rotation", UMXPicoBerryToolText.RotationParam)] string rotation = null,
            [CliArg("scale", UMXPicoBerryToolText.ScaleParam)] string scale = null,
            [CliArg("parent", UMXPicoBerryToolText.ParentParam)] string parent = null)
        {
            var buildError = UMXPicoBerryRequestBuilder.BuildPlace(
                sessionId: sessionId,
                assetId: assetId,
                name: name,
                position: position,
                rotation: rotation,
                scale: scale,
                parent: parent,
                out var request);

            if (buildError != null) return Task.FromResult(UMXPipelineResponse.Unwrap(buildError));

            return UMXPipelineResponse.UnwrapAsync(PicoBerryPlaceOperation.ExecuteAsync(request));
        }

        [CliCommand(
            "umx_picoberry_list",
            UMXPicoBerryToolText.ListDescription,
            Tags = new[] { "umodelerx/picoberry" })]
        public static Task<object> List(
            [CliArg("query", UMXPicoBerryToolText.QueryParam)] string query = null,
            [CliArg("page", UMXPicoBerryToolText.PageParam)] int page = 1,
            [CliArg("limit", UMXPicoBerryToolText.LimitParam)] int limit = PicoBerryListRequest.DefaultLimit)
        {
            var request = new PicoBerryListRequest
            {
                Query = query,
                Page = page,
                Limit = limit > 0 ? limit : PicoBerryListRequest.DefaultLimit,
            };
            return UMXPipelineResponse.UnwrapAsync(PicoBerryListOperation.ExecuteAsync(request));
        }
    }
}
