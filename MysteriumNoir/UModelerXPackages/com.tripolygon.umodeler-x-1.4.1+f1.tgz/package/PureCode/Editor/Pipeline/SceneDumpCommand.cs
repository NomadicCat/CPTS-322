using Tripolygon.UModelerX.Editor.MCP;
using Unity.Pipeline.Commands;

namespace Tripolygon.UModelerX.Editor.Pipeline
{
    // Unity Pipeline 어댑터. 프로토콜 변환만 담당하고 실제 실행은 UMXSceneDumpOperation 으로 위임.
    static class SceneDumpCommand
    {
        [CliCommand(
            "umx_scene_dump",
            UMXMcpUtility.SceneDumpToolDescription,
            Tags = new[] { "umodelerx/scene" })]
        public static object Dump(
            [CliArg("target", "Optional. \"name\" or #id — dump only that object and its children.")]
            string target = null,
            [CliArg("scope", "Optional. 'scene' (default) or 'selection'.")]
            string scope = null)
        {
            return UMXPipelineResponse.Unwrap(UMXSceneDumpOperation.Execute(target, scope));
        }
    }
}
